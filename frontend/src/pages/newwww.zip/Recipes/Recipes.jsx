import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Link } from 'react-router-dom';
import './Recipes.css';

// ─── Import Images for Flavors ──────────────────────────────────────────────
// Replace these paths with your actual image locations

// Fallback / additional images

// ─── Data ────────────────────────────────────────────────────────────────────

const CATEGORIES = [
  { id: 'pizza', title: 'Khakhra Pizza', count: 8, sub: 'Crispy, healthy pizza bases', accent: '#E86A2A' },
  { id: 'chaat', title: 'Khakhra Chaat', count: 12, sub: 'Street food with a crunch', accent: '#C4501A' },
  { id: 'sandwich', title: 'Khakhra Sandwich', count: 6, sub: 'Layered meals, every occasion', accent: '#F4923D' },
  { id: 'soup', title: 'Soup & Crumbles', count: 5, sub: 'Warm bowls with texture', accent: '#A84010' },
  { id: 'dessert', title: 'Khakhra Desserts', count: 4, sub: 'Sweet innovations', accent: '#D66020' },
  { id: 'party', title: 'Party Platters', count: 10, sub: 'Celebrate with crunch', accent: '#E87840' },
];

const QUICK_RECIPES = [
  { slug: 'khakhra-bhel', title: 'Khakhra Bhel', time: '5 min', difficulty: 'Easy', serves: 2, flavor: 'Curry Leaves' },
  { slug: 'masala-khakhra-toast', title: 'Masala Khakhra Toast', time: '7 min', difficulty: 'Easy', serves: 1, flavor: 'Garlic' },
  { slug: 'chutney-khakhra', title: 'Chutney Crunch Toast', time: '3 min', difficulty: 'Easy', serves: 2, flavor: 'Methi' },
  { slug: 'avocado-khakhra', title: 'Avocado Smash Khakhra', time: '5 min', difficulty: 'Easy', serves: 2, flavor: 'Moringa' },
  { slug: 'khakhra-nachos', title: 'Khakhra Nachos Bowl', time: '8 min', difficulty: 'Easy', serves: 3, flavor: 'Garlic' },
  { slug: 'cucumber-raita', title: 'Cucumber Raita Stack', time: '6 min', difficulty: 'Easy', serves: 2, flavor: 'Methi' },
];

const ALL_RECIPES = [
  { slug: 'garlic-pizza', title: 'Garlic Khakhra Pizza', category: 'pizza', time: '15 min', difficulty: 'Easy', serves: 2, rating: 4.8, reviews: 156, tags: ['Vegetarian', 'High-Fiber'], flavor: 'Garlic' },
  { slug: 'curry-chaat', title: 'Curry Leaves Chaat', category: 'chaat', time: '12 min', difficulty: 'Easy', serves: 3, rating: 4.7, reviews: 189, tags: ['Vegan', 'Quick'], flavor: 'Curry Leaves' },
  { slug: 'moringa-sandwich', title: 'Moringa Layered Sandwich', category: 'sandwich', time: '10 min', difficulty: 'Easy', serves: 2, rating: 4.9, reviews: 112, tags: ['Healthy', 'Travel-Ready'], flavor: 'Moringa' },
  { slug: 'methi-bhel', title: 'Methi Khakhra Bhel', category: 'chaat', time: '8 min', difficulty: 'Easy', serves: 2, rating: 4.6, reviews: 94, tags: ['Diabetic-Friendly', 'Low-GI'], flavor: 'Methi' },
  { slug: 'chocolate-bark', title: 'Chocolate Khakhra Bark', category: 'dessert', time: '20 min', difficulty: 'Medium', serves: 4, rating: 4.9, reviews: 203, tags: ['Dessert', 'Festive'], flavor: 'Plain' },
  { slug: 'canapes', title: 'Khakhra Canapés', category: 'party', time: '15 min', difficulty: 'Medium', serves: 6, rating: 4.8, reviews: 134, tags: ['Party', 'Elegant'], flavor: 'Garlic' },
  { slug: 'tomato-crunch', title: 'Tomato Soup Crunch Bowl', category: 'soup', time: '20 min', difficulty: 'Easy', serves: 2, rating: 4.5, reviews: 87, tags: ['Winter-Warmer', 'Comfort'], flavor: 'Methi' },
  { slug: 'party-platter', title: 'Grand Party Platter', category: 'party', time: '25 min', difficulty: 'Medium', serves: 8, rating: 5.0, reviews: 67, tags: ['Party', 'Diwali'], flavor: 'Mixed' },
  { slug: 'pesto-pizza', title: 'Pesto Veggie Khakhra Pizza', category: 'pizza', time: '18 min', difficulty: 'Easy', serves: 2, rating: 4.7, reviews: 145, tags: ['Vegetarian', 'Italian-Twist'], flavor: 'Moringa' },
  { slug: 'ladoo-crumble', title: 'Coconut Ladoo Crumble', category: 'dessert', time: '15 min', difficulty: 'Easy', serves: 6, rating: 4.8, reviews: 98, tags: ['Festive', 'Sweet'], flavor: 'Coconut' },
  { slug: 'bruschetta', title: 'Khakhra Bruschetta', category: 'sandwich', time: '10 min', difficulty: 'Easy', serves: 3, rating: 4.6, reviews: 76, tags: ['Mediterranean', 'Quick'], flavor: 'Garlic' },
  { slug: 'post-workout', title: 'Post-Workout Power Bowl', category: 'soup', time: '10 min', difficulty: 'Easy', serves: 1, rating: 4.7, reviews: 123, tags: ['High-Protein', 'Fitness'], flavor: 'Garlic' },
];

const DIP_RECIPES = [
  { slug: 'mint-chutney', title: 'Mint-Coriander Chutney', time: '10 min', difficulty: 'Easy', pairing: 'All khakhra flavors' },
  { slug: 'red-pepper-hummus', title: 'Roasted Red Pepper Hummus', time: '15 min', difficulty: 'Medium', pairing: 'Garlic or Plain Khakhra' },
  { slug: 'coconut-yogurt', title: 'Coconut Yogurt Dip', time: '5 min', difficulty: 'Easy', pairing: 'Curry Leaves Khakhra' },
  { slug: 'peanut-chutney', title: 'Peanut-Coconut Chutney', time: '12 min', difficulty: 'Easy', pairing: 'All flavors' },
  { slug: 'spicy-salsa', title: 'Spicy Tomato Salsa', time: '10 min', difficulty: 'Easy', pairing: 'Garlic Khakhra' },
];

const MEAL_PREP = [
  { title: 'Office Lunch Box', detail: '2 Khakhras + dip cup + fresh fruit = 400 kcal balanced meal', cal: 400 },
  { title: 'Kids Tiffin Box', detail: 'Mini khakhra sandwiches + cheese cubes + grapes = 320 kcal', cal: 320 },
  { title: 'Travel Snack Pack', detail: '4 khakhras in airtight container + trail mix = 450 kcal', cal: 450 },
  { title: 'Post-Workout Box', detail: 'Khakhra + protein spread + banana = 380 kcal', cal: 380 },
];

// ─── Colour helper ────────────────────────────────────────────────────────────

const DIFF_COLORS = { Easy: '#2E7D4F', Medium: '#C4501A', Advanced: '#8B2010' };

const publicImage = (filename) => `${process.env.PUBLIC_URL}/images/${filename}`;

// ─── Image mapping based on flavor ───────────────────────────────────────────
const getImageForFlavor = (flavor) => {
  const flavorLower = flavor?.toLowerCase() || '';
  if (flavorLower.includes('curry')) return publicImage('curry leaves.jpg');
  if (flavorLower.includes('garlic')) return publicImage('garlic.jpg');
  if (flavorLower.includes('jeera') || flavorLower.includes('cumin')) return publicImage('jeera.jpg');
  if (flavorLower.includes('methi')) return publicImage('methi.jpg');
  if (flavorLower.includes('onion')) return publicImage('onion.jpg');
  if (flavorLower.includes('moringa')) return publicImage('moringa.jpg');
  if (flavorLower.includes('coconut')) return publicImage('mm.jpeg');
  if (flavorLower.includes('mixed')) return publicImage('mm.jpeg');
  return publicImage('mm.jpeg');
};

// ─── Intersection Observer Hook (re‑triggers on every scroll in/out) ─────────

function useInView(threshold = 0.1) {
  const ref = useRef(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setInView(entry.isIntersecting);
      },
      { threshold }
    );
    const currentRef = ref.current;
    if (currentRef) observer.observe(currentRef);
    return () => {
      if (currentRef) observer.unobserve(currentRef);
    };
  }, [threshold]);
  return [ref, inView];
}

// ─── Animated Card Wrapper (zoom effect) ─────────────────────────────────────

function AnimatedCard({ children, delay = 0, className = '' }) {
  const [ref, inView] = useInView(0.1);
  return (
    <div
      ref={ref}
      className={`rc-animated-card ${inView ? 'rc-animated-in' : ''} ${className}`}
      style={{
        transitionDelay: `${delay}ms`,
        transform: inView ? 'scale(1)' : 'scale(0.85)',
        opacity: inView ? 1 : 0,
      }}
    >
      {children}
    </div>
  );
}

// ─── Recipe Card (for All Recipes) ─────────────────────────────────────────

function RecipeCard({ recipe, delay = 0 }) {
  const imageSrc = getImageForFlavor(recipe.flavor);
  return (
    <AnimatedCard delay={delay} className="rc-recipe-card">
      <Link to={`/recipes/${recipe.slug}`} className="rc-recipe-card-link">
        <div className="rc-card-img-wrap">
          <div className="rc-card-img-placeholder">
            <img src={imageSrc} alt={recipe.flavor} className="rc-card-img" />
            <div className="rc-card-overlay" />
            <span className="rc-card-flavor-tag">{recipe.flavor}</span>
          </div>
          <div className="rc-card-time-badge">{recipe.time}</div>
        </div>
        <div className="rc-card-body">
          {recipe.rating && (
            <div className="rc-card-rating">
              <span className="rc-star">&#9733;</span>
              <span>{recipe.rating}</span>
              <span className="rc-reviews">({recipe.reviews})</span>
            </div>
          )}
          <h3 className="rc-card-title">{recipe.title}</h3>
          <div className="rc-card-meta">
            <span className="rc-difficulty" style={{ color: DIFF_COLORS[recipe.difficulty] || '#C4501A' }}>
              {recipe.difficulty}
            </span>
            {recipe.serves && <span>Serves {recipe.serves}</span>}
          </div>
          {recipe.tags && (
            <div className="rc-card-tags">
              {recipe.tags.slice(0, 2).map(t => (
                <span key={t} className="rc-tag">{t}</span>
              ))}
            </div>
          )}
        </div>
      </Link>
    </AnimatedCard>
  );
}

// ─── Quick Card ────────────────────────────────────────────────────────────

function QuickCard({ recipe, delay = 0 }) {
  const imageSrc = getImageForFlavor(recipe.flavor);
  return (
    <AnimatedCard delay={delay} className="rc-quick-card">
      <Link to={`/recipes/${recipe.slug}`} className="rc-quick-card-link">
        <div className="rc-quick-img">
          <img src={imageSrc} alt={recipe.flavor} className="rc-quick-img-bg" />
          <span className="rc-quick-time">{recipe.time}</span>
        </div>
        <div className="rc-quick-body">
          <span className="rc-quick-diff" style={{ color: DIFF_COLORS[recipe.difficulty] }}>{recipe.difficulty}</span>
          <h4 className="rc-quick-title">{recipe.title}</h4>
          <p className="rc-quick-sub">{recipe.flavor} Khakhra · Serves {recipe.serves}</p>
        </div>
      </Link>
    </AnimatedCard>
  );
}

// ─── Category Card ─────────────────────────────────────────────────────────

function CategoryCard({ cat, delay = 0 }) {
  const [hovered, setHovered] = useState(false);
  return (
    <AnimatedCard delay={delay} className="rc-cat-card">
      <Link
        to={`/recipes?category=${cat.id}`}
        className={`rc-cat-card-link ${hovered ? 'rc-cat-hovered' : ''}`}
        style={{ '--cat-accent': cat.accent }}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
      >
        <div className="rc-cat-accent-bar" />
        <div className="rc-cat-body">
          <div className="rc-cat-count">{cat.count} recipes</div>
          <h3 className="rc-cat-title">{cat.title}</h3>
          <p className="rc-cat-sub">{cat.sub}</p>
          <span className="rc-cat-arrow">&#8594;</span>
        </div>
      </Link>
    </AnimatedCard>
  );
}

// ─── Dip Card ──────────────────────────────────────────────────────────────

function DipCard({ dip, delay = 0 }) {
  return (
    <AnimatedCard delay={delay} className="rc-dip-card">
      <Link to={`/recipes/${dip.slug}`} className="rc-dip-card-link">
        <div className="rc-dip-pill">{dip.time}</div>
        <h4 className="rc-dip-title">{dip.title}</h4>
        <p className="rc-dip-pairing">Pairs with: {dip.pairing}</p>
        <span className="rc-dip-diff" style={{ color: DIFF_COLORS[dip.difficulty] }}>{dip.difficulty}</span>
      </Link>
    </AnimatedCard>
  );
}

// ─── Hero Section (centered, no search) ────────────────────────────────────

function HeroSection() {
  const [scrollY, setScrollY] = useState(0);
  useEffect(() => {
    const handler = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);

  return (
    <section className="rc-hero">
      <div className="rc-hero-bg" style={{ transform: `translateY(${scrollY * 0.2}px)` }} />
      <div className="rc-hero-overlay" />
      <div className="rc-hero-content rc-hero-content--centered">
        <div className="rc-hero-left rc-hero-left--centered">
          <div className="rc-hero-eyebrow">
            <span className="rc-eyebrow-bar" />
            Culinary Creativity
          </div>
          <h1 className="rc-hero-h1">
            Beyond Snacking<br />
            <em>with WIN-DIA</em>
          </h1>
          <p className="rc-hero-desc">
            Transform your favourite khakhra into pizzas, chaats, sandwiches, desserts and more.
            Every recipe is tested, healthy and delicious.
          </p>
        </div>
      </div>
    </section>
  );
}

// ─── Categories Section ─────────────────────────────────────────────────────

function CategoriesSection() {
  return (
    <section className="rc-section rc-categories-section">
      <div className="rc-container">
        <div className="rc-section-hdr">
          <div className="rc-overline">Browse by Type</div>
          <h2 className="rc-h2">Explore Recipe Categories</h2>
        </div>
        <div className="rc-categories-grid">
          {CATEGORIES.map((cat, i) => (
            <CategoryCard key={cat.id} cat={cat} delay={i * 80} />
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Quick & Easy Section ──────────────────────────────────────────────────

function QuickSection() {
  return (
    <section className="rc-section rc-quick-section">
      <div className="rc-container">
        <div className="rc-section-hdr">
          <div className="rc-overline">Under 10 Minutes</div>
          <h2 className="rc-h2">Quick &amp; Easy Recipes</h2>
          <p className="rc-section-sub">Perfect for busy days when you need something fast and nourishing.</p>
        </div>
        <div className="rc-quick-grid">
          {QUICK_RECIPES.map((r, i) => (
            <QuickCard key={r.slug} recipe={r} delay={i * 70} />
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── All Recipes Grid ───────────────────────────────────────────────────────

function AllRecipesSection() {
  const [visible, setVisible] = useState(8);
  const shown = ALL_RECIPES.slice(0, visible);

  return (
    <section className="rc-section rc-all-section">
      <div className="rc-container">
        <div className="rc-section-hdr rc-section-hdr--row">
          <div>
            <div className="rc-overline">Full Collection</div>
            <h2 className="rc-h2">All Recipes</h2>
          </div>
          <span className="rc-recipe-count">{ALL_RECIPES.length} recipes</span>
        </div>
        <div className="rc-all-grid">
          {shown.map((r, i) => (
            <RecipeCard key={r.slug} recipe={r} delay={(i % 4) * 80} />
          ))}
        </div>
        {visible < ALL_RECIPES.length && (
          <div className="rc-load-more-wrap">
            <button className="rc-load-more" onClick={() => setVisible(v => v + 8)}>
              Load More Recipes &#8595;
            </button>
          </div>
        )}
      </div>
    </section>
  );
}

// ─── Meal Prep Section ──────────────────────────────────────────────────────

function MealPrepSection() {
  return (
    <section className="rc-section rc-meal-section">
      <div className="rc-container">
        <div className="rc-section-hdr">
          <div className="rc-overline">Effortless Planning</div>
          <h2 className="rc-h2">Meal Prep Ideas</h2>
          <p className="rc-section-sub">WIN-DIA khakhra in your weekly meal plan — ready in minutes.</p>
        </div>
        <div className="rc-meal-grid">
          {MEAL_PREP.map((m, i) => (
            <AnimatedCard key={m.title} delay={i * 100} className="rc-meal-card">
              <div className="rc-meal-cal">
                <strong>{m.cal}</strong>
                <span>kcal</span>
              </div>
              <div className="rc-meal-body">
                <h3>{m.title}</h3>
                <p>{m.detail}</p>
              </div>
            </AnimatedCard>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Dips Section ───────────────────────────────────────────────────────────

function DipsSection() {
  return (
    <section className="rc-section rc-dips-section">
      <div className="rc-container">
        <div className="rc-section-hdr">
          <div className="rc-overline">Perfect Pairings</div>
          <h2 className="rc-h2">Homemade Dips &amp; Spreads</h2>
          <p className="rc-section-sub">Every dip recipe crafted to elevate your khakhra experience.</p>
        </div>
        <div className="rc-dips-grid">
          {DIP_RECIPES.map((d, i) => (
            <DipCard key={d.slug} dip={d} delay={i * 80} />
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Submit CTA ─────────────────────────────────────────────────────────────

function SubmitCTA() {
  return (
    <section className="rc-submit-section">
      <div className="rc-container">
        <div className="rc-submit-panel">
          <div className="rc-submit-text">
            <div className="rc-overline rc-overline-lt">Win Prizes</div>
            <h2 className="rc-submit-h">Share Your WIN-DIA Creation</h2>
            <p>Have a unique way to enjoy WIN-DIA khakhra? Share it with our community of home cooks. Top recipe wins Rs.5000 and gets featured on our website.</p>
          </div>
          <div className="rc-submit-right">
            <div className="rc-submit-prize">
              <strong>Rs. 5,000</strong>
              <span>Top recipe prize</span>
            </div>
            <div className="rc-submit-prize">
              <strong>Featured</strong>
              <span>On our website</span>
            </div>
            <Link to="/submit-recipe" className="rc-submit-btn">Submit Your Recipe &#8594;</Link>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Newsletter ─────────────────────────────────────────────────────────────

function NewsletterSection() {
  const [email, setEmail] = useState('');
  const [done, setDone] = useState(false);
  const submit = (e) => {
    e.preventDefault();
    if (email) setDone(true);
  };
  return (
    <section className="rc-section rc-newsletter-section">
      <div className="rc-container">
        <div className="rc-newsletter-inner">
          <div className="rc-newsletter-text">
            <div className="rc-overline">Stay Inspired</div>
            <h2 className="rc-h2">New Recipes Every Friday</h2>
            <p>Join 25,000+ home cooks getting creative WIN-DIA recipes delivered to their inbox. Free e-book included when you subscribe.</p>
          </div>
          <div className="rc-newsletter-form-wrap">
            {done ? (
              <div className="rc-newsletter-success">
                You are subscribed! Check your inbox for your free e-book.
              </div>
            ) : (
              <form className="rc-newsletter-form" onSubmit={submit}>
                <input
                  type="email"
                  placeholder="Enter your email address"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  required
                />
                <button type="submit">Subscribe &#8594;</button>
              </form>
            )}
            <p className="rc-newsletter-bonus">Free e-book: "15 Quick WIN-DIA Recipes" on subscribe</p>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Main Component ─────────────────────────────────────────────────────────

const Recipes = () => {
  return (
    <div className="rc-page">
      <HeroSection />
      <CategoriesSection />
      <QuickSection />
      <AllRecipesSection />
      <MealPrepSection />
      <DipsSection />
      <SubmitCTA />
      <NewsletterSection />
    </div>
  );
};

export default Recipes;
