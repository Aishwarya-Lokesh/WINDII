import React, { useState } from 'react';
import './Contact.css';

const Contact = () => {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <div className="contact-page">
      <div className="container contact-grid">
        <section className="contact-info">
          <span className="section-label">Contact Us</span>
          <h1>Let's talk about your order</h1>
          <p>If you need help with an order, want to partner with WIN-DIA, or have a bulk inquiry, we're here to help.</p>
          <div className="contact-cards">
            <div>
              <strong>Email</strong>
              <p>info@win-dia.com</p>
            </div>
            <div>
              <strong>Phone</strong>
              <p>+91 98765 43210</p>
            </div>
            <div>
              <strong>Address</strong>
              <p>Bengaluru, Karnataka, India</p>
            </div>
          </div>
        </section>

        <form className="contact-form" onSubmit={handleSubmit}>
          <label>
            Name
            <input name="name" value={form.name} onChange={handleChange} required />
          </label>
          <label>
            Email
            <input name="email" type="email" value={form.email} onChange={handleChange} required />
          </label>
          <label>
            Subject
            <input name="subject" value={form.subject} onChange={handleChange} required />
          </label>
          <label>
            Message
            <textarea name="message" value={form.message} onChange={handleChange} required />
          </label>
          <button type="submit" className="btn btn-primary">Send Message</button>
          {sent && <p className="success-message">Your message was sent successfully!</p>}
        </form>
      </div>
    </div>
  );
};

export default Contact;
